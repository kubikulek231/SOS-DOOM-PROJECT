#include "config.h"
#ifndef __STDC_LIMIT_MACROS
#define __STDC_LIMIT_MACROS
#endif
#include "globit.c"

// vim: set sw=4 ts=4 et:
