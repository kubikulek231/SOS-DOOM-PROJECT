#ifndef WPIXRES_H
#define WPIXRES_H

class WPixRes {
public:

    static void initPixmaps(class IResourceLocator* locator);
    static void freePixmaps();

};

#endif

// vim: set sw=4 ts=4 et:
