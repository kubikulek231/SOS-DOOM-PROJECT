#ifndef __PREFS_H
#define __PREFS_H

#include "default.h"
#include "bindkey.h"

#endif

// vim: set sw=4 ts=4 et:
