#ifndef KEYSYMS_H
#define KEYSYMS_H

unsigned short ucsToKeysym(int ucs);

#endif
